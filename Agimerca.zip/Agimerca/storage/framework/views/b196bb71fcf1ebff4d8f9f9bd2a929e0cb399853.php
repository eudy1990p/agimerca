<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
<div class="modal-dialog" role="document">	
	<div class="modal-content">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span> </button>
			<h4 class="modal-title" id="myModalLabel">Agregar Categoria</h4>
		</div>
		<div class="modal-body" >
				<form>	
				<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" id="token">
					<input type="hidden" name="id"  id="id"><br><br>
					<div id="divCategoria" class="form-group text-center">
                        <label class="control-label" for="categoria">Categoria</label>
                        <input type="text" class="form-control" id="categoria" placeholder="Categoria">
                    </div>
				</form>
			
			

		</div>
		<div class="modal-footer">
			 <div class="form-group">
                    <div class="row">
                        <div class="col-md-5 col-md-offset-4 col-xs-12">
                         <button id="registro" type="submit" class="btn btn-success">Enviar</button>
                        <button id="btnCancelar" type="button" class="btn btn-danger">Cancelar</button>
                        </div>
                        
                    </div>
                </div>
		</div>
		</form>
	</div>
	</div>
</div>