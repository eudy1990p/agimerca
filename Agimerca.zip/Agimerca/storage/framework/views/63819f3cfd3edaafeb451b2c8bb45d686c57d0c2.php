<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Agimerca</title>
    <script src="js/jquery-1.11.1.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/alertify.min.css">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/datepicker3.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <script src="js/lumino.glyphs.js"></script>

    
</head>
<body>

  <nav class="navbar navbar-inverse navbar-fixed-top " id="python0214" role="navigation">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#"><span>Agim</span>erca</a>
                <ul class="user-menu">
                    <li class="dropdown pull-right"><?php if(Auth::guest()): ?>
                    <a class="btn btn-primary" href="<?php echo e(url('/register')); ?>">Registrar</a>
                    <a class="btn btn-primary" href="<?php echo e(url('/login')); ?>">Login</a><?php else: ?>
                        
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg> <?php echo e(Auth::user()->name); ?><span class="caret"></span></a>
                        <ul class="dropdown-menu" role="menu">
                            <li><a href="<?php echo e(url('/perfil')); ?>"><svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg> Perfil</a></li>
                            
                            <li><a href="<?php echo e(url('/logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"><svg class="glyph stroked arrow left"><use xlink:href="#stroked-arrow-left"/></svg>
                                            Salir
                                        </a>

                                        <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form></li>
                        </ul>
                    </li>
                    
                </ul><?php endif; ?>
            </div>
                            
        </div><!-- /.container-fluid -->
    </nav>
        
    <div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
        <form role="search">
            <div class="form-group">
                <input type="text" class="form-control" placeholder="Buscar">
            </div>
        </form>
        <ul class="nav menu">
            <li ><a href="<?php echo e(url('/')); ?>"><svg class="glyph stroked dashboard-dial"><use xlink:href="#stroked-dashboard-dial"></use></svg> Inicio</a></li>
            <li><a href="<?php echo e(url('/usuario')); ?>"><svg class="glyph stroked calendar"><use xlink:href="#stroked-calendar"></use></svg> Usuarios</a></li>
            <li><a href="<?php echo e(url('/categoria')); ?>"><svg class="glyph stroked table"><use xlink:href="#stroked-table">Articulos</use></svg>Categoria</a></li>
            <li><a href="forms.html"><svg class="glyph stroked pencil"><use xlink:href="#stroked-pencil"></use></svg>Mas</a></li>
            <li><a href="panels.html"><svg class="glyph stroked app-window"><use xlink:href="#stroked-app-window"></use></svg> Alerts &amp; Panels</a></li>
            <li><a href="icons.html"><svg class="glyph stroked star"><use xlink:href="#stroked-star"></use></svg> Contacto</a></li>
            <li class="parent ">
                <a href="#">
                    <span data-toggle="collapse" href="#sub-item-1"><svg class="glyph stroked chevron-down"><use xlink:href="#stroked-chevron-down"></use></svg></span> Dropdown 
                </a>
                <ul class="children collapse" id="sub-item-1">
                    <li>
                        <a class="" href="#">
                            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Sub Item 1
                        </a>
                    </li>
                    <li>
                        <a class="" href="#">
                            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Sub Item 2
                        </a>
                    </li>
                 <?php if(Auth::user()->nombre_id == 2): ?>   <li>
                        <a class="" href="#">
                            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Sub Item 3
                        </a>
                    </li><?php endif; ?>
                </ul>
            </li>
            <li role="presentation" class="divider"></li>
            
        </ul>

    </div><!--/.sidebar-->
<?php echo $__env->yieldContent('content'); ?>
    <script src="js/alertify.min.js"></script>
    <script src="js/bootstrap.min.js"></script>    
    <script src="js/bootstrap-datepicker.js"></script>

</body>
</html>