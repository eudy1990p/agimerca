@extends('layouts.principal')

	@section('content')

	<div class="row">
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
            <ol class="breadcrumb">
                <li><a href="{{ url('/')}}"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
                <li class="active">Perfil</li>
            </ol>
        </div>
			

			<div class="row">
				
				  <center> <h1 class="page-header">Perfil</h1></center>
				    <!-- left column -->
				    <div class="col-md-4 col-sm-6 col-xs-12">
				      <div class="text-center">
				        <img src="http://lorempixel.com/200/200/people/9/" class="avatar img-circle img-thumbnail" alt="avatar">
				        <h6>Cambiar foto de perfil</h6>
				        <input type="file" class="text-center center-block well well-sm">
				      </div>
				    </div>
				    <!-- edit form column -->
				    <div class="col-md-8 col-sm-6 col-xs-12 personal-info">
				      <h3>Informacion personal</h3>
				      <form class="form-horizontal" role="form">
				        <div class="form-group">
				          <label class="col-lg-3 control-label">First name:</label>
				          <div class="col-lg-8">
				            <input class="form-control" value="Jane" type="text">
				          </div>
				        </div>
				        <div class="form-group">
				          <label class="col-lg-3 control-label">Last name:</label>
				          <div class="col-lg-8">
				            <input class="form-control" value="Bishop" type="text">
				          </div>
				        </div>
				        <div class="form-group">
				          <label class="col-lg-3 control-label">Company:</label>
				          <div class="col-lg-8">
				            <input class="form-control" value="" type="text">
				          </div>
				        </div>
				        <div class="form-group">
				          <label class="col-lg-3 control-label">Email:</label>
				          <div class="col-lg-8">
				            <input class="form-control" value="janesemail@gmail.com" type="text">
				          </div>
				        </div>
				        <div class="form-group">
				          <label class="col-lg-3 control-label">Time Zone:</label>
				          <div class="col-lg-8">
				            <div class="ui-select">
				              <select id="user_time_zone" class="form-control">
				                <option value="Hawaii">(GMT-10:00) Hawaii</option>
				                <option value="Alaska">(GMT-09:00) Alaska</option>
				                <option value="Pacific Time (US & Canada)">(GMT-08:00) Pacific Time (US & Canada)</option>
				                <option value="Arizona">(GMT-07:00) Arizona</option>
				                <option value="Mountain Time (US & Canada)">(GMT-07:00) Mountain Time (US & Canada)</option>
				                <option value="Central Time (US & Canada)" selected="selected">(GMT-06:00) Central Time (US & Canada)</option>
				                <option value="Eastern Time (US & Canada)">(GMT-05:00) Eastern Time (US & Canada)</option>
				                <option value="Indiana (East)">(GMT-05:00) Indiana (East)</option>
				              </select>
				            </div>
				          </div>
				        </div>
				        <div class="form-group">
				          <label class="col-md-3 control-label">Username:</label>
				          <div class="col-md-8">
				            <input class="form-control" value="janeuser" type="text">
				          </div>
				        </div>
				        <div class="form-group">
				          <label class="col-md-3 control-label">Password:</label>
				          <div class="col-md-8">
				            <input class="form-control" value="11111122333" type="password">
				          </div>
				        </div>
				        <div class="form-group">
				          <label class="col-md-3 control-label">Confirm password:</label>
				          <div class="col-md-8">
				            <input class="form-control" value="11111122333" type="password">
				          </div>
				        </div>
				        <div class="form-group">
				          <label class="col-md-3 control-label"></label>
				          <div class="col-md-8">
				            <input class="btn btn-primary" value="Save Changes" type="button">
				            <span></span>
				            <input class="btn btn-default" value="Cancel" type="reset">
				          </div>
				        </div>
				      </form>
				    </div>
				  
				</div>
			
		</div>
	</div>

@endsection