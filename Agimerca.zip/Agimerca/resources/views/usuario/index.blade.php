@extends('layouts.admin')
	@section('content')

	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main"> 
			<div class="row">
			<br>
            <ol class="breadcrumb">
                <li><a href="#"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
                <li class="active">Usuarios</li>
            </ol>
        </div><!--/.row-->

	</div>
	<div class="row">
	<div class="col-md-1"></div>
		<div class="col-sm-9 col-sm-offset-3 col-lg-7 col-lg-offset-2 main">
			<br><br><div class="col-md-3 col-sm-9 main"></div>
			<div class="col-lg-7 col-md-6 col-sm-6">
				<svg class="glyph stroked male user "><use xlink:href="#stroked-male-user"/></svg><br><br><br>	
			</div>
			</div>
    	</div>		
     <div class="col-sm-9 col-sm-offset-3 col-lg-7 col-lg-offset-2 main">
        <div class="row">
         <div class="col-md-1"></div>
          <div class="col-md-">
         <div class="col-md-5 col-md-offset-4 col-xs-12"></div> <button type="button" id="abrirForm" class="btn btn-success">Agregar Nuevo</button>
          <div id="contenedorFormulario" class="container">
              <form id="form_registro_usuarios">
                <div class="row row-flex row-flex-wrap">
                    <input type="hidden" id="usuario2"><br><br>
                    <div id="divUsuario" class="form-group text-center col-md-5 col-xs-12">
                        <label class="control-label" for="usuario">Usuario</label>
                        <input type="text" class="form-control" id="usuario" placeholder="Usuario">
                    </div>
                    <div id="divCorreo" class="form-group text-center col-md-5 col-xs-12">
                        <label class="control-label" for="correo">Correo</label>
                        <input type="email" class="form-control" id="correo" placeholder="Correo">
                    </div>
                    <div id="divClave" class="form-group text-center col-md-5 col-xs-12">
                        <label class="control-label" for="clave">Contraseña</label>
                        <input type="password" class="form-control" id="clave" placeholder="Contraseña">
                    </div>
                    <div id="divClave2" class="form-group text-center col-md-5 col-xs-12">
                        <label class="control-label" for="clave2">Repita la Contraseña</label>
                        <input type="password" class="form-control" id="clave2" placeholder="Repita la contraseña">
                    </div>                   
                    <div id="divRol" class="form-group text-center col-md-5 col-md-offset-2 col-xs-12">
                        <label class="control-label" for="rol">Rol</label>
                        <select class="form-control" id="rol">
                            <option disabled selected>- Seleccione un rol -</option>
                           @foreach($roles as $roles)
                            <option value="">{{$roles}}</option>
                           @endforeach
                        </select>
                    </div>
                    
                </div>
                <div class="form-group">
                    <div class="row">
                        <div class="col-md-5 col-md-offset-4 col-xs-12">
                         <button id="btnAccion" type="submit" class="btn btn-success">Guardar</button>
                        <button id="btnCancelar" type="button" class="btn btn-danger">Cancelar</button>
                        </div>
                        <center></center>
                    </div>
                </div>
            </form>
        </div>
          </div>     
         </div>
        </div>
        <br><br>
      	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
      		<div class="row">
      			<div class="col-md-1"></div>
      				<div class="col-md-9">
      					<table class="table">           
		                            <thead>
		                                <th>No.</th>
		                                <th>Nombre</th>
		                                <th>Correo</th>
		                                <th>Tipo de Us</th>
		                                <th>Operaciones</th>
		                            </thead>
		                            <tbody id="listar-user"> </tbody>
		               		 </table>
      				</div>
      				
      			</div>
      		</div>
 
	
						</div>

	<script type="text/javascript" src="js/usuario/usuario.js"></script>

@endsection



