<table class="table">           
                            <thead>
                                <th>No.</th>
                                <th>Nombre</th>
                                <th>Correo</th>
                                <th>Tipo de Us</th>
                                <th>Operaciones</th>

                            </thead>
                                <?php $no=1; ?>
                            @foreach($users as $user)
                            <tbody>
                                <td>{{$no++}}</td>
                                <td>{{$user->name}}</td>
                                <td>{{$user->email}}</td>
                                <td>{{$user->nombre_id}}</td>

                                <td>
                                    <form class="" action="{{route('usuario.destroy',$user->id)}}" method="post">
                                        <input type="hidden" name="_method" value="delete">
                                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                        <a href="{{route('usuario.edit',$user->id)}}" class="btn btn-primary"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></a>
                                        <input type="submit" class="btn btn-danger" onclick="return confirm('Estas seguro que deseas Eliminar este Usuario');" name="name" value="Eliminar">

                                    </form>
                                </td>
                            </tbody>
                            @endforeach
                        </table>