<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Confirmacion de Cuenta</title>
</head>
<body>
	<h1>Gracias por registrarte</h1>

	<p>Para activar tu cuenta en Agirmerca sigue  este enlace <a href='{{ url("register/confirm/{$user->token}") }}'>Confirmar Cuenta</a></p>
</body>
</html>