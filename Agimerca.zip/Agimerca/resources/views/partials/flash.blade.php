@if(session('status'))

			<div class="alert bg-success" role="alert">
					<svg class="glyph stroked checkmark"><use xlink:href="#stroked-checkmark"></use></svg> {{ session('status')}} <a href="#" class="pull-right"><span class="glyphicon glyphicon-remove"></span></a>
				</div>
	
	
@endif