@extends('layouts.admin')
	@section('content')
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main"> 
		<div class="row">
			<br>
            <ol class="breadcrumb">
                <li><a href="{{url('/admin')}}"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
                <li class="active">Categoria</li>
            </ol>
        </div>
	</div>
	<div class="col-md-1"></div>
		<div class="col-sm-9 col-sm-offset-3 col-lg-7 col-lg-offset-2 main">
			<br><br><div class="col-md-3 col-sm-9 main"></div>
				<div class="col-lg-7 col-md-6 col-sm-6">
				<svg class="glyph stroked clipboard with paper"><use xlink:href="#stroked-clipboard-with-paper"/></svg><br><br><button class="btn btn-primary" data-toggle="modal" data-target="#myModal">Agregar Nueva</button>	
			</div>
		@include('categoria.modal')
	</div>
    	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
      		<br><br><div class="row">
      			<div class="col-md-1"></div>
      				<div class="col-md-7 col-sm-9">
      					<table class="table">           
                            <thead>
                                <th>Nombre</th>
                                <th>Operaciones</th>
                            </thead>
                            <tbody id="listar-cat"> </tbody>
               		    </table>
      				</div>	
      			</div>
      		</div>	


<script src="js/categoria/categoria.js"></script>
@endsection