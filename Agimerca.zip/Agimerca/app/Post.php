<?php

namespace Agimerca;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    //
}
