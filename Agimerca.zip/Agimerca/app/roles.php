<?php

namespace Agimerca;

use Illuminate\Database\Eloquent\Model;

class roles extends Model
{
    protected $table="roles";
    protected $fillable=['nombre'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
