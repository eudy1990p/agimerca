<?php

namespace Agimerca\Http\Middleware;
use Illuminate\Support\Facades\Auth;
use Illuminate\Contracts\Auth\Guard;
use Closure;

class AdminMiddleware
{
    protected $admin;

    public function __construct(Guard $admin){
        $this->admin =  $admin;
    }
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if($this->admin->user()->nombre_id !=1){

        return back()->with('status', 'No tienes Privilegios');
        return redirect()->to('/');
        }
        return $next($request);
    }
}
