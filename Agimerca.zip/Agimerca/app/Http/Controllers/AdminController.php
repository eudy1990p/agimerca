<?php

namespace Agimerca\Http\Controllers;

use Illuminate\Http\Request;

class AdminController extends Controller
{
	public function __construct(){
		$this->middleware('AdminMiddleware');
	}


   public function index(){
    	return view('layouts.admin');
    }
}
