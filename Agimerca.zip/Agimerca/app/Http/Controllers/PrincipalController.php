<?php

namespace Agimerca\Http\Controllers;

use Illuminate\Http\Request;

class PrincipalController extends Controller
{
	 public function __construct()
    {
        $this->middleware('auth');
    }
    
    public function index(){
    	return view('index');
    }

    public function perfil(){
    	return view('usuario.perfil');
    }
}
