$(document).ready(function(){
listCat();
});

var tableDatos = $('#listar-cat');
var listCat = function(){
	$.ajax({
		type:"get",
		url:"http://localhost:8000/listallc",
		success:  function(data){
			$(data).each(function(key, value){
			tableDatos.append('<tr><td>'+value.nombre+'</td><td> <button value='+value.id+' OnClick=""  type="button" class="btn btn-primary" "><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></button> <button type="button" value='+value.id+' OnClick="" class="btn btn-danger"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></button></td></tr>')					
			});
		}
	});
}

$("#registro").click(function(){
		var  datos = $('#categoria').val();
		var  route = "http://localhost:8000/categorias";
		var token =$("#token").val();

		$.ajax({
				url: route,
				headers:{'X-CSRF-TOKEN':token},
				type:'POST',
				dataType:'json',
				data:{categoria:datos},
				success: function(){
					alertify.success('Categoria creada');
				}	
		});		

});

