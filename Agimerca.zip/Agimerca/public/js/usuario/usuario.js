$(document).ready(function(){
	listUser();
	$('#contenedorFormulario').hide();
	
});
var n=0;
	$('#abrirForm').on('click',function(){
        if(n%2==0){
            $('#contenedorFormulario').fadeIn();
            $(this).html('Cerrar');
            $(this).removeClass('btn-success');
            $(this).addClass('btn-primary');
            $('#btnCancelar').click();
        }else{
            $('#contenedorFormulario').fadeOut();
            $(this).html('Agregar Nuevo');
            $(this).removeClass('btn-primary');
            $(this).addClass('btn-success');
            $('#btnCancelar').click();
        }
        n++;
    });
	var no=1
	var	tabaDatos = $("#listar-user");
	var listUser = function(){
		$.ajax({
			type:"get",
			url:"http://localhost:8000/listall",
			success: function(data){
				$(data).each(function(key,value){
					tabaDatos.append('<tr><td></td><td>'+value.name+'</td><td>'+value.email+'</td><td>'+value.nombre_id+'</td><td> <button value='+value.id+' OnClick=""  type="button" class="btn btn-primary" "><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></button> <button type="button" value='+value.id+' OnClick="" class="btn btn-danger"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></button></td></tr>');
				});
			}
		});
	}

 

