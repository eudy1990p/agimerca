<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/

Route::get('/','PrincipalController@index');

Auth::routes();


Route::get('/home', 'HomeController@index');
Route::get('/perfil', 'PrincipalController@perfil');

//admin
Route::get('/admin', 'AdminController@index');
//Admin Usuario
Route::resource('/usuario','UsuarioController');
Route::get('/listall','UsuarioController@listall');

//Admin Caterotia
Route::resource('/categoria','CategoriaController');
Route::post('categorias','CategoriaController@store');
Route::get('/listallc', 'CategoriaController@listall');